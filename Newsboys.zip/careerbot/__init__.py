"""BDjobs-only CareerNewsBot package."""
