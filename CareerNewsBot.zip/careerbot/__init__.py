"""CareerNewsBot job intelligence package."""
