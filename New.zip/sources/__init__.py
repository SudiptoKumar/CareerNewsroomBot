"""CareerNewsroom source adapters."""
